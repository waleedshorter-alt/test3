import os
import asyncio
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")
GUILD_ID = int(GUILD_ID) if GUILD_ID and GUILD_ID.strip().isdigit() else None
PREFIX = os.getenv("PREFIX", "!")
BOT_STATUS = os.getenv("BOT_STATUS", "Managing the server")

# ---- Intents ----
# NOTE: "Server Members Intent" and "Message Content Intent" must ALSO be
# enabled for your bot in the Discord Developer Portal (Bot tab), or the
# bot will fail to start / features like welcome messages won't fire.
intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.reactions = True
intents.invites = True


class MyBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=PREFIX, intents=intents, help_command=None)

    async def setup_hook(self):
        extensions = [
            "cogs.verification",
            "cogs.tickets",
            "cogs.announcements",
            "cogs.selfroles",
            "cogs.giveaways",
            "cogs.welcome",
            "cogs.moderation",
            "cogs.invites",
        ]
        for ext in extensions:
            try:
                await self.load_extension(ext)
                print(f"[OK] Loaded extension: {ext}")
            except Exception as e:
                print(f"[FAIL] Could not load {ext}: {e}")

        # Sync slash commands. If GUILD_ID is set, sync instantly to that
        # guild (recommended during development). Otherwise sync globally
        # (can take up to an hour to propagate).
        if GUILD_ID:
            guild_obj = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=guild_obj)
            await self.tree.sync(guild=guild_obj)
            print(f"Synced commands to guild {GUILD_ID}")
        else:
            await self.tree.sync()
            print("Synced commands globally")


bot = MyBot()


@bot.event
async def on_ready():
    print("=" * 50)
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print("=" * 50)
    try:
        await bot.change_presence(activity=discord.Game(name=BOT_STATUS))
    except Exception:
        pass


def main():
    if not TOKEN:
        raise SystemExit(
            "ERROR: DISCORD_TOKEN is not set. Copy .env.example to .env "
            "and fill in your bot token before starting the bot."
        )
    bot.run(TOKEN)


if __name__ == "__main__":
    main()
