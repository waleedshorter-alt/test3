# All-in-One Discord Server Bot

A single Discord bot (slash commands + buttons) covering:

- 🎫 **Ticket system** — category select menu → private channel + close button
- ✅ **Verification** — "agree to rules" button gate before granting a role
- 📢 **Announcements** — `/announce` embed with optional role ping
- 🎭 **Self-roles by reaction** — build a panel, react to get/remove a role
- 🎉 **Giveaways** — `/giveaway`, auto-ends and picks winners, `/reroll`
- 👋 **Welcome messages** — join/leave embeds + optional auto-role + optional DM
- 🔨 **Moderation** — `/ban` `/unban` `/kick` `/timeout` `/untimeout` `/clear` `/warn`
- 📨 **Invite tracker** — credits whoever invited a new member, flags likely fake
  accounts, decrements the inviter if the member leaves, plus a leaderboard and
  admin bonus/remove/reset commands

All server-specific values (role IDs, channel IDs, etc.) are configured
through **environment variables** in a `.env` file — no code editing needed.

---

## 1. Create the bot application

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications) → **New Application**.
2. Go to the **Bot** tab → **Add Bot**.
3. Under **Privileged Gateway Intents**, enable:
   - **Server Members Intent**
   - **Message Content Intent**
4. Click **Reset Token** and copy it — this goes in `DISCORD_TOKEN`.
5. Go to **OAuth2 → URL Generator**:
   - Scopes: `bot`, `applications.commands`
   - Bot permissions: at minimum `Manage Roles`, `Manage Channels`, `Kick Members`,
     `Ban Members`, `Moderate Members`, `Manage Messages`, `Send Messages`,
     `Embed Links`, `Read Message History`, `Add Reactions`, `View Channels`,
     **`Manage Server`** (required for the invite tracker to read invite data).
   - Open the generated URL and invite the bot to your server.

> **Role position matters:** in Server Settings → Roles, drag the bot's role
> **above** any role you want it to assign/remove (verified role, self-roles,
> auto-role) and above any member roles it needs to ban/kick/timeout.

## 2. Install

Requires **Python 3.10+**.

```bash
cd discord-bot
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Or just run the included startup script, which does all of this for you:

```bash
./start.sh        # Linux/macOS
start.bat         # Windows
```

## 3. Configure environment variables

```bash
cp .env.example .env
```

Open `.env` and fill in the values. Every variable is documented inline.
The only **required** one to get the bot online is `DISCORD_TOKEN`; the rest
enable individual features (e.g. leave `WELCOME_CHANNEL_ID` blank to skip
welcome messages).

To get an ID for a channel/role/category: enable **Developer Mode**
(User Settings → Advanced), then right-click the item → **Copy ID**.

| Variable | Used by | Required? |
|---|---|---|
| `DISCORD_TOKEN` | Core | ✅ Yes |
| `GUILD_ID` | Core (instant command sync while testing) | Recommended |
| `PREFIX`, `BOT_STATUS` | Core | No |
| `TICKET_CATEGORY_ID`, `TICKET_SUPPORT_ROLE_ID`, `TICKET_LOG_CHANNEL_ID` | Tickets | No |
| `VERIFIED_ROLE_ID`, `VERIFICATION_CHANNEL_ID` | Verification | For that feature |
| `ANNOUNCEMENT_CHANNEL_ID` | Announcements | No (can pass a channel per-command) |
| `WELCOME_CHANNEL_ID`, `WELCOME_DM_ENABLED`, `AUTO_ROLE_ID` | Welcome | No |
| `GIVEAWAY_EMOJI` | Giveaways | No (defaults to 🎉) |
| `MOD_LOG_CHANNEL_ID`, `MUTE_ROLE_ID` | Moderation | No |
| `INVITE_LOG_CHANNEL_ID`, `FAKE_ACCOUNT_AGE_DAYS` | Invite tracker | No (needs bot to have Manage Server) |

## 4. Run it

```bash
python bot.py
```

You should see `Logged in as YourBot#0000` in the console.

## 5. Set up each feature in your server

Run these once per server (all require the relevant permission, e.g. Administrator):

- `/setup_verification` — posts the verification panel in the current channel.
- `/setup_tickets` — posts the ticket panel in the current channel.
- `/create_selfrole_panel title:"Pick your roles" description:"React below!"`
  then `/add_selfrole message_id:<id> emoji:🔵 role:@Blue Team` (repeat per role).
- `/announce message:"Server update!" ping_role:@everyone`
- `/giveaway prize:"Nitro" duration_minutes:60 winners:1`

The invite tracker needs no setup command — it starts tracking automatically
as soon as the bot is online (as long as it has the **Manage Server**
permission). Members can check `/invites` and `/invite_leaderboard`; admins
can adjust counts with `/add_invites`, `/remove_invites`, and wipe everything
with `/reset_invites`.

Moderation commands (`/ban`, `/kick`, `/timeout`, `/clear`, `/warn`, etc.) work
immediately as long as the invoking member and the bot have the right permissions.

## Project structure

```
discord-bot/
├── bot.py                # Entry point — loads cogs, syncs slash commands
├── config.py             # Reads every setting from environment variables
├── requirements.txt
├── .env.example          # Copy to .env and fill in
├── start.sh / start.bat  # One-command startup scripts
├── cogs/
│   ├── verification.py
│   ├── tickets.py
│   ├── announcements.py
│   ├── selfroles.py
│   ├── giveaways.py
│   ├── welcome.py
│   ├── moderation.py
│   └── invites.py
├── utils/
│   └── storage.py        # Tiny JSON persistence layer
└── data/                 # Auto-created JSON files (tickets, self-roles, giveaways)
```

## Persistence

Ticket, self-role, and giveaway state is stored as JSON files in `data/`
so it survives a bot restart. This is fine for small/medium servers; swap
`utils/storage.py` for a real database if you need higher scale or
concurrency.

## Keeping it running 24/7

For a VPS, use a process manager so it restarts on crash/reboot, e.g.:

```bash
pip install pm2 -g   # or use systemd / screen / tmux / Docker
pm2 start bot.py --interpreter python3 --name discord-bot
```

Or wrap it in a simple `systemd` service that runs `start.sh` on boot.

**Deploying to Railway?** See [`RAILWAY.md`](./RAILWAY.md) for step-by-step
instructions, including how to persist `data/` across redeploys with a volume.
