"""
Central place where every environment variable used by the bot is read.
All the actual values live in your .env file (copy .env.example -> .env).
Nothing needs to be hard-coded or edited in the Python files themselves.
"""

import os
from dotenv import load_dotenv

load_dotenv()


def _int(name: str, default: int = 0) -> int:
    val = os.getenv(name)
    try:
        return int(val) if val else default
    except ValueError:
        return default


def _bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


# ---- Core ----
PREFIX = os.getenv("PREFIX", "!")
BOT_STATUS = os.getenv("BOT_STATUS", "Managing the server")

# ---- Tickets ----
TICKET_CATEGORY_ID = _int("TICKET_CATEGORY_ID")
TICKET_SUPPORT_ROLE_ID = _int("TICKET_SUPPORT_ROLE_ID")
TICKET_LOG_CHANNEL_ID = _int("TICKET_LOG_CHANNEL_ID")

# ---- Verification ----
VERIFIED_ROLE_ID = _int("VERIFIED_ROLE_ID")
VERIFICATION_CHANNEL_ID = _int("VERIFICATION_CHANNEL_ID")

# ---- Announcements ----
ANNOUNCEMENT_DEFAULT_CHANNEL_ID = _int("ANNOUNCEMENT_CHANNEL_ID")

# ---- Welcome / Auto role ----
WELCOME_CHANNEL_ID = _int("WELCOME_CHANNEL_ID")
WELCOME_DM_ENABLED = _bool("WELCOME_DM_ENABLED", False)
AUTO_ROLE_ID = _int("AUTO_ROLE_ID")

# ---- Giveaways ----
GIVEAWAY_EMOJI = os.getenv("GIVEAWAY_EMOJI", "🎉")

# ---- Moderation ----
MOD_LOG_CHANNEL_ID = _int("MOD_LOG_CHANNEL_ID")
MUTE_ROLE_ID = _int("MUTE_ROLE_ID")

# ---- Invite Tracker ----
INVITE_LOG_CHANNEL_ID = _int("INVITE_LOG_CHANNEL_ID")
# Accounts younger than this many days are counted as "fake" invites
# (they still show under the inviter but don't count toward their total).
FAKE_ACCOUNT_AGE_DAYS = _int("FAKE_ACCOUNT_AGE_DAYS", 7)
