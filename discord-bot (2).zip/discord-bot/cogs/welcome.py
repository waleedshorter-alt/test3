import discord
from discord.ext import commands

import config


class Welcome(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        channel = member.guild.get_channel(config.WELCOME_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title="👋 Welcome!",
                description=(
                    f"Welcome to **{member.guild.name}**, {member.mention}! "
                    "We're glad to have you here."
                ),
                color=discord.Color.green(),
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"Member #{member.guild.member_count}")
            await channel.send(embed=embed)

        if config.AUTO_ROLE_ID:
            role = member.guild.get_role(config.AUTO_ROLE_ID)
            if role:
                try:
                    await member.add_roles(role, reason="Auto role on join")
                except discord.Forbidden:
                    pass

        if config.WELCOME_DM_ENABLED:
            try:
                await member.send(f"Welcome to {member.guild.name}! Glad to have you here. 🎉")
            except discord.Forbidden:
                pass  # user has DMs disabled

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        channel = member.guild.get_channel(config.WELCOME_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                description=f"**{member}** has left the server.",
                color=discord.Color.red(),
            )
            await channel.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Welcome(bot))
