import discord
from discord import app_commands
from discord.ext import commands

import config


class RulesAgreeView(discord.ui.View):
    """Shown privately to a user before they get verified — forces an
    explicit 'I agree to the rules' click."""

    def __init__(self):
        super().__init__(timeout=120)

    @discord.ui.button(label="I have read and agree to the rules", style=discord.ButtonStyle.success)
    async def agree(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = interaction.guild.get_role(config.VERIFIED_ROLE_ID)
        if role is None:
            await interaction.response.edit_message(
                content="⚠️ Verification role is not configured. Ask an admin to set VERIFIED_ROLE_ID in .env.",
                view=None,
            )
            return
        await interaction.user.add_roles(role, reason="Self-verification (agreed to rules)")
        await interaction.response.edit_message(
            content="✅ You're verified! Welcome to the server.", view=None
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Verification cancelled.", view=None)


class VerifyPanelView(discord.ui.View):
    """The persistent public panel posted in the verification channel."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="✅ Verify Me", style=discord.ButtonStyle.success, custom_id="verify_panel_button")
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = interaction.guild.get_role(config.VERIFIED_ROLE_ID)
        if role and role in interaction.user.roles:
            await interaction.response.send_message("You are already verified.", ephemeral=True)
            return
        await interaction.response.send_message(
            "Please confirm below to complete verification:",
            view=RulesAgreeView(),
            ephemeral=True,
        )


class Verification(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Re-register the persistent view so the button keeps working
        # after a bot restart.
        self.bot.add_view(VerifyPanelView())

    @app_commands.command(name="setup_verification", description="Post the verification panel in this channel")
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_verification(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="🔐 Server Verification",
            description=(
                "Click the button below, then confirm you agree to the rules "
                "to gain full access to the server."
            ),
            color=discord.Color.blurple(),
        )
        await interaction.channel.send(embed=embed, view=VerifyPanelView())
        await interaction.response.send_message("Verification panel posted.", ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Verification(bot))
