"""
Invite tracker.

Tracks which invite link each new member used, credits the inviter,
handles fake accounts (too new to trust) and members who later leave
(decrements the inviter), supports a manual bonus/removal command for
admins, and a leaderboard.

Requires the "Manage Server" permission for the bot (to read guild.invites())
and the INVITES privileged... actually non-privileged gateway intent
(intents.invites = True, already set in bot.py).
"""

import datetime

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils import storage

VANITY_CODE = "VANITY"


def _empty_stats():
    return {"regular": 0, "bonus": 0, "fake": 0, "left": 0}


def _total(stats: dict) -> int:
    return stats["regular"] + stats["bonus"] - stats["fake"] - stats["left"]


class Invites(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # in-memory cache: {guild_id: {invite_code: uses}}
        self.invite_cache: dict[int, dict[str, int]] = {}

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------
    async def _snapshot_guild_invites(self, guild: discord.Guild) -> dict[str, int]:
        snapshot = {}
        try:
            for inv in await guild.invites():
                snapshot[inv.code] = inv.uses or 0
        except discord.Forbidden:
            pass  # bot lacks Manage Server permission in this guild

        if guild.features and "VANITY_URL" in guild.features:
            try:
                vanity = await guild.vanity_invite()
                if vanity:
                    snapshot[VANITY_CODE] = vanity.uses or 0
            except (discord.Forbidden, discord.HTTPException):
                pass
        return snapshot

    @commands.Cog.listener()
    async def on_ready(self):
        for guild in self.bot.guilds:
            self.invite_cache[guild.id] = await self._snapshot_guild_invites(guild)

    @commands.Cog.listener()
    async def on_guild_join(self, guild: discord.Guild):
        self.invite_cache[guild.id] = await self._snapshot_guild_invites(guild)

    @commands.Cog.listener()
    async def on_invite_create(self, invite: discord.Invite):
        self.invite_cache.setdefault(invite.guild.id, {})[invite.code] = invite.uses or 0

    @commands.Cog.listener()
    async def on_invite_delete(self, invite: discord.Invite):
        self.invite_cache.setdefault(invite.guild.id, {}).pop(invite.code, None)

    # ------------------------------------------------------------------
    # Join / leave tracking
    # ------------------------------------------------------------------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild = member.guild
        before = self.invite_cache.get(guild.id, {})
        after = await self._snapshot_guild_invites(guild)
        self.invite_cache[guild.id] = after

        used_code = None
        inviter: discord.User | None = None
        for code, uses in after.items():
            if uses > before.get(code, 0):
                used_code = code
                break

        if used_code:
            try:
                if used_code == VANITY_CODE:
                    vanity = await guild.vanity_invite()
                    inviter = None  # vanity invites have no meaningful inviter
                else:
                    matching = [i for i in await guild.invites() if i.code == used_code]
                    if matching:
                        inviter = matching[0].inviter
            except (discord.Forbidden, discord.HTTPException):
                inviter = None

        account_age_days = (datetime.datetime.now(datetime.timezone.utc) - member.created_at).days
        is_fake = account_age_days < config.FAKE_ACCOUNT_AGE_DAYS

        joins = await storage.load("invite_joins", {})
        guild_joins = joins.setdefault(str(guild.id), {})

        if inviter and not inviter.bot:
            invites_data = await storage.load("invites", {})
            guild_invites = invites_data.setdefault(str(guild.id), {})
            stats = guild_invites.setdefault(str(inviter.id), _empty_stats())

            if is_fake:
                stats["fake"] += 1
            else:
                stats["regular"] += 1

            guild_invites[str(inviter.id)] = stats
            invites_data[str(guild.id)] = guild_invites
            await storage.save("invites", invites_data)

            guild_joins[str(member.id)] = {"inviter_id": inviter.id, "fake": is_fake}
        else:
            guild_joins[str(member.id)] = {"inviter_id": None, "fake": is_fake}

        joins[str(guild.id)] = guild_joins
        await storage.save("invite_joins", joins)

        await self._log_join(member, inviter, used_code, is_fake)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        guild = member.guild
        joins = await storage.load("invite_joins", {})
        guild_joins = joins.get(str(guild.id), {})
        record = guild_joins.pop(str(member.id), None)
        if record is None:
            return
        joins[str(guild.id)] = guild_joins
        await storage.save("invite_joins", joins)

        inviter_id = record.get("inviter_id")
        if not inviter_id or record.get("fake"):
            return  # fake joins were never counted as "regular", nothing to remove

        invites_data = await storage.load("invites", {})
        guild_invites = invites_data.setdefault(str(guild.id), {})
        stats = guild_invites.get(str(inviter_id))
        if stats:
            stats["left"] += 1
            guild_invites[str(inviter_id)] = stats
            invites_data[str(guild.id)] = guild_invites
            await storage.save("invites", invites_data)

    async def _log_join(self, member, inviter, used_code, is_fake):
        channel = member.guild.get_channel(config.INVITE_LOG_CHANNEL_ID)
        if not channel:
            return

        if used_code == VANITY_CODE:
            desc = f"{member.mention} joined using the **vanity invite link**."
        elif inviter:
            invites_data = await storage.load("invites", {})
            stats = invites_data.get(str(member.guild.id), {}).get(str(inviter.id), _empty_stats())
            tag = " *(flagged as a new/fake account)*" if is_fake else ""
            desc = (
                f"{member.mention} was invited by **{inviter}**{tag}.\n"
                f"{inviter.mention} now has **{_total(stats)}** invite(s)."
            )
        else:
            desc = f"{member.mention} joined, but I couldn't determine who invited them."

        embed = discord.Embed(description=desc, color=discord.Color.blurple())
        embed.set_footer(text=f"Account created {member.created_at.strftime('%Y-%m-%d')}")
        await channel.send(embed=embed)

    # ------------------------------------------------------------------
    # Slash commands
    # ------------------------------------------------------------------
    @app_commands.command(name="invites", description="Check how many invites a member has")
    @app_commands.describe(member="Member to check (defaults to you)")
    async def invites_cmd(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        invites_data = await storage.load("invites", {})
        stats = invites_data.get(str(interaction.guild.id), {}).get(str(member.id), _empty_stats())

        embed = discord.Embed(
            title=f"Invites — {member.display_name}",
            color=discord.Color.blurple(),
        )
        embed.add_field(name="Total", value=str(_total(stats)), inline=True)
        embed.add_field(name="Regular", value=str(stats["regular"]), inline=True)
        embed.add_field(name="Bonus", value=str(stats["bonus"]), inline=True)
        embed.add_field(name="Left", value=str(stats["left"]), inline=True)
        embed.add_field(name="Fake", value=str(stats["fake"]), inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="invite_leaderboard", description="Show the top inviters in this server")
    @app_commands.describe(limit="How many entries to show (default 10, max 25)")
    async def invite_leaderboard(self, interaction: discord.Interaction, limit: app_commands.Range[int, 1, 25] = 10):
        invites_data = await storage.load("invites", {})
        guild_invites = invites_data.get(str(interaction.guild.id), {})

        ranked = sorted(guild_invites.items(), key=lambda kv: _total(kv[1]), reverse=True)
        ranked = [r for r in ranked if _total(r[1]) > 0][:limit]

        if not ranked:
            await interaction.response.send_message("No invites have been tracked yet.", ephemeral=True)
            return

        lines = []
        medals = {0: "🥇", 1: "🥈", 2: "🥉"}
        for i, (user_id, stats) in enumerate(ranked):
            prefix = medals.get(i, f"`#{i + 1}`")
            lines.append(f"{prefix} <@{user_id}> — **{_total(stats)}** invites")

        embed = discord.Embed(
            title=f"🏆 Invite Leaderboard — {interaction.guild.name}",
            description="\n".join(lines),
            color=discord.Color.gold(),
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="add_invites", description="[Admin] Add bonus invites to a member")
    @app_commands.describe(member="Member to credit", amount="Number of bonus invites to add")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def add_invites(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1000]):
        invites_data = await storage.load("invites", {})
        guild_invites = invites_data.setdefault(str(interaction.guild.id), {})
        stats = guild_invites.setdefault(str(member.id), _empty_stats())
        stats["bonus"] += amount
        guild_invites[str(member.id)] = stats
        invites_data[str(interaction.guild.id)] = guild_invites
        await storage.save("invites", invites_data)
        await interaction.response.send_message(
            f"✅ Gave {member.mention} {amount} bonus invite(s). They now have **{_total(stats)}** total."
        )

    @app_commands.command(name="remove_invites", description="[Admin] Remove invites from a member")
    @app_commands.describe(member="Member to adjust", amount="Number of invites to remove")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def remove_invites(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1000]):
        invites_data = await storage.load("invites", {})
        guild_invites = invites_data.setdefault(str(interaction.guild.id), {})
        stats = guild_invites.setdefault(str(member.id), _empty_stats())
        stats["bonus"] -= amount
        guild_invites[str(member.id)] = stats
        invites_data[str(interaction.guild.id)] = guild_invites
        await storage.save("invites", invites_data)
        await interaction.response.send_message(
            f"✅ Removed {amount} invite(s) from {member.mention}. They now have **{_total(stats)}** total."
        )

    @app_commands.command(name="reset_invites", description="[Admin] Reset ALL invite stats for this server")
    @app_commands.checks.has_permissions(administrator=True)
    async def reset_invites(self, interaction: discord.Interaction):
        invites_data = await storage.load("invites", {})
        invites_data[str(interaction.guild.id)] = {}
        await storage.save("invites", invites_data)

        joins = await storage.load("invite_joins", {})
        joins[str(interaction.guild.id)] = {}
        await storage.save("invite_joins", joins)

        await interaction.response.send_message("🗑️ All invite stats for this server have been reset.", ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Invites(bot))
