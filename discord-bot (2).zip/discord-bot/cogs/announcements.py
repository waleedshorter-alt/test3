import discord
from discord import app_commands
from discord.ext import commands

import config


class Announcements(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="announce", description="Send an announcement embed")
    @app_commands.describe(
        message="The announcement content",
        title="Optional title for the embed",
        channel="Channel to post in (defaults to the configured announcement channel)",
        ping_role="Role to mention above the embed",
        image_url="Optional image URL to attach",
    )
    @app_commands.checks.has_permissions(manage_messages=True)
    async def announce(
        self,
        interaction: discord.Interaction,
        message: str,
        title: str = "📢 Announcement",
        channel: discord.TextChannel = None,
        ping_role: discord.Role = None,
        image_url: str = None,
    ):
        target = (
            channel
            or interaction.guild.get_channel(config.ANNOUNCEMENT_DEFAULT_CHANNEL_ID)
            or interaction.channel
        )

        embed = discord.Embed(title=title, description=message, color=discord.Color.gold())
        embed.set_footer(text=f"Announced by {interaction.user.display_name}")
        embed.timestamp = discord.utils.utcnow()
        if image_url:
            embed.set_image(url=image_url)

        content = ping_role.mention if ping_role else None
        allowed = discord.AllowedMentions(roles=True) if ping_role else discord.AllowedMentions.none()

        await target.send(content=content, embed=embed, allowed_mentions=allowed)
        await interaction.response.send_message(f"✅ Announcement sent to {target.mention}", ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Announcements(bot))
