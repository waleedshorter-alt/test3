from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

import config


def role_check(actor: discord.Member, target: discord.Member) -> bool:
    """Returns True if the actor is allowed to act on the target based on
    role hierarchy (guild owner always allowed)."""
    if actor.guild.owner_id == actor.id:
        return True
    return actor.top_role > target.top_role


class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def log_action(self, guild: discord.Guild, description: str):
        channel = guild.get_channel(config.MOD_LOG_CHANNEL_ID)
        if channel:
            embed = discord.Embed(description=description, color=discord.Color.orange())
            embed.timestamp = discord.utils.utcnow()
            await channel.send(embed=embed)

    # ---------------- BAN ----------------
    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(member="Member to ban", reason="Reason for the ban")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        if not role_check(interaction.user, member):
            await interaction.response.send_message(
                "You can't ban someone with an equal or higher role than you.", ephemeral=True
            )
            return
        await member.ban(reason=f"{reason} | by {interaction.user}")
        await interaction.response.send_message(f"🔨 Banned {member.mention} — {reason}")
        await self.log_action(interaction.guild, f"**{member}** was banned by **{interaction.user}** — {reason}")

    @app_commands.command(name="unban", description="Unban a user by their ID")
    @app_commands.describe(user_id="The Discord user ID to unban", reason="Reason for the unban")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided"):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await interaction.guild.unban(user, reason=reason)
        except (discord.NotFound, ValueError):
            await interaction.response.send_message("Could not find a banned user with that ID.", ephemeral=True)
            return
        await interaction.response.send_message(f"✅ Unbanned {user}")
        await self.log_action(interaction.guild, f"**{user}** was unbanned by **{interaction.user}** — {reason}")

    # ---------------- KICK ----------------
    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(member="Member to kick", reason="Reason for the kick")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        if not role_check(interaction.user, member):
            await interaction.response.send_message(
                "You can't kick someone with an equal or higher role than you.", ephemeral=True
            )
            return
        await member.kick(reason=f"{reason} | by {interaction.user}")
        await interaction.response.send_message(f"👢 Kicked {member.mention} — {reason}")
        await self.log_action(interaction.guild, f"**{member}** was kicked by **{interaction.user}** — {reason}")

    # ---------------- TIMEOUT ----------------
    @app_commands.command(name="timeout", description="Timeout (mute) a member for a set duration")
    @app_commands.describe(
        member="Member to timeout",
        minutes="Duration in minutes (max 40320 = 28 days)",
        reason="Reason for the timeout",
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutes: app_commands.Range[int, 1, 40320],
        reason: str = "No reason provided",
    ):
        if not role_check(interaction.user, member):
            await interaction.response.send_message(
                "You can't timeout someone with an equal or higher role than you.", ephemeral=True
            )
            return
        await member.timeout(timedelta(minutes=minutes), reason=f"{reason} | by {interaction.user}")
        await interaction.response.send_message(
            f"⏱️ Timed out {member.mention} for {minutes} minute(s) — {reason}"
        )
        await self.log_action(
            interaction.guild,
            f"**{member}** was timed out for {minutes}m by **{interaction.user}** — {reason}",
        )

    @app_commands.command(name="untimeout", description="Remove an active timeout from a member")
    @app_commands.describe(member="Member to remove timeout from")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member):
        await member.timeout(None, reason=f"Timeout removed by {interaction.user}")
        await interaction.response.send_message(f"✅ Removed timeout from {member.mention}")

    # ---------------- PURGE ----------------
    @app_commands.command(name="clear", description="Bulk delete recent messages in this channel")
    @app_commands.describe(amount="Number of messages to delete (max 100)")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def clear(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🧹 Deleted {len(deleted)} messages.", ephemeral=True)

    # ---------------- WARN ----------------
    @app_commands.command(name="warn", description="Warn a member (sent as a DM + logged)")
    @app_commands.describe(member="Member to warn", reason="Reason for the warning")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        await interaction.response.send_message(f"⚠️ {member.mention} has been warned — {reason}")
        await self.log_action(interaction.guild, f"**{member}** was warned by **{interaction.user}** — {reason}")
        try:
            await member.send(f"You have been warned in **{interaction.guild.name}**: {reason}")
        except discord.Forbidden:
            pass  # user has DMs disabled

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        elif isinstance(error, discord.Forbidden):
            await interaction.response.send_message(
                "I don't have permission to do that — check my role is above the target's role.", ephemeral=True
            )
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
