import random
import time

import discord
from discord import app_commands
from discord.ext import commands, tasks

import config
from utils import storage


class Giveaways(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.check_giveaways.start()

    def cog_unload(self):
        self.check_giveaways.cancel()

    @app_commands.command(name="giveaway", description="Start a giveaway")
    @app_commands.describe(
        prize="What is being given away",
        duration_minutes="How long the giveaway should run, in minutes",
        winners="Number of winners (default 1)",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def giveaway(
        self,
        interaction: discord.Interaction,
        prize: str,
        duration_minutes: app_commands.Range[int, 1, 43200],
        winners: app_commands.Range[int, 1, 20] = 1,
    ):
        end_time = time.time() + duration_minutes * 60
        embed = discord.Embed(
            title="🎉 Giveaway 🎉",
            description=(
                f"**Prize:** {prize}\n"
                f"React with {config.GIVEAWAY_EMOJI} to enter!\n"
                f"**Winners:** {winners}\n"
                f"**Ends:** <t:{int(end_time)}:R>"
            ),
            color=discord.Color.magenta(),
        )
        embed.set_footer(text=f"Hosted by {interaction.user.display_name}")

        await interaction.response.send_message("Giveaway started!", ephemeral=True)
        msg = await interaction.channel.send(embed=embed)
        await msg.add_reaction(config.GIVEAWAY_EMOJI)

        data = await storage.load("giveaways", {})
        data[str(msg.id)] = {
            "channel_id": interaction.channel.id,
            "prize": prize,
            "winners": winners,
            "end_time": end_time,
            "ended": False,
        }
        await storage.save("giveaways", data)

    @app_commands.command(name="reroll", description="Reroll the winner(s) of a finished giveaway")
    @app_commands.describe(message_id="The message ID of the finished giveaway")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def reroll(self, interaction: discord.Interaction, message_id: str):
        data = await storage.load("giveaways", {})
        gw = data.get(message_id)
        if not gw:
            await interaction.response.send_message("No giveaway found with that message ID.", ephemeral=True)
            return
        await interaction.response.send_message("Rerolling...", ephemeral=True)
        await self.end_giveaway(message_id, gw, reroll=True)

    @tasks.loop(seconds=30)
    async def check_giveaways(self):
        data = await storage.load("giveaways", {})
        changed = False
        for msg_id, gw in list(data.items()):
            if gw.get("ended"):
                continue
            if time.time() >= gw["end_time"]:
                await self.end_giveaway(msg_id, gw)
                gw["ended"] = True
                changed = True
        if changed:
            await storage.save("giveaways", data)

    async def end_giveaway(self, msg_id, gw, reroll: bool = False):
        channel = self.bot.get_channel(gw["channel_id"])
        if not channel:
            return
        try:
            msg = await channel.fetch_message(int(msg_id))
        except discord.NotFound:
            return

        reaction = discord.utils.get(msg.reactions, emoji=config.GIVEAWAY_EMOJI)
        entrants = []
        if reaction:
            async for user in reaction.users():
                if not user.bot:
                    entrants.append(user)

        if not entrants:
            await channel.send(f"No valid entries for the **{gw['prize']}** giveaway. No winner could be chosen.")
            return

        chosen = random.sample(entrants, min(gw["winners"], len(entrants)))
        mentions = ", ".join(w.mention for w in chosen)
        prefix = "🔁 New winner(s)" if reroll else "🎉 Congratulations"
        await channel.send(f"{prefix} {mentions}! You won **{gw['prize']}**!")

    @check_giveaways.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Giveaways(bot))
