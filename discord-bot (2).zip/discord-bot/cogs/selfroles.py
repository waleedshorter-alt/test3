import discord
from discord import app_commands
from discord.ext import commands

from utils import storage


class SelfRoles(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="create_selfrole_panel", description="Create a new self-role message")
    @app_commands.describe(title="Panel title", description="Panel description")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def create_selfrole_panel(self, interaction: discord.Interaction, title: str, description: str):
        embed = discord.Embed(title=title, description=description, color=discord.Color.teal())
        msg = await interaction.channel.send(embed=embed)

        data = await storage.load("selfroles", {})
        data[str(msg.id)] = {"channel_id": interaction.channel.id, "roles": {}}
        await storage.save("selfroles", data)

        await interaction.response.send_message(
            f"Panel created (message ID: `{msg.id}`). Use `/add_selfrole` to attach roles to it.",
            ephemeral=True,
        )

    @app_commands.command(name="add_selfrole", description="Add a reaction role to an existing self-role panel")
    @app_commands.describe(
        message_id="ID of the panel message (from /create_selfrole_panel)",
        emoji="Emoji to react with",
        role="Role to assign when a user reacts",
    )
    @app_commands.checks.has_permissions(manage_roles=True)
    async def add_selfrole(
        self, interaction: discord.Interaction, message_id: str, emoji: str, role: discord.Role
    ):
        data = await storage.load("selfroles", {})
        entry = data.get(message_id)
        if not entry:
            await interaction.response.send_message(
                "No panel found with that message ID. Create one first with `/create_selfrole_panel`.",
                ephemeral=True,
            )
            return

        channel = interaction.guild.get_channel(entry["channel_id"])
        try:
            msg = await channel.fetch_message(int(message_id))
        except (discord.NotFound, discord.HTTPException, ValueError):
            await interaction.response.send_message("Could not find the panel message.", ephemeral=True)
            return

        try:
            await msg.add_reaction(emoji)
        except discord.HTTPException:
            await interaction.response.send_message(
                "I couldn't react with that emoji — make sure it's a valid unicode emoji or one from this server.",
                ephemeral=True,
            )
            return

        entry["roles"][emoji] = role.id
        data[message_id] = entry
        await storage.save("selfroles", data)

        embed = msg.embeds[0] if msg.embeds else discord.Embed(title="Self Roles")
        current = embed.description or ""
        embed.description = current + f"\n{emoji} — {role.mention}"
        await msg.edit(embed=embed)

        await interaction.response.send_message(f"Added {emoji} → {role.mention} to the panel.", ephemeral=True)

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if payload.member is None or payload.member.bot:
            return
        data = await storage.load("selfroles", {})
        entry = data.get(str(payload.message_id))
        if not entry:
            return
        role_id = entry["roles"].get(str(payload.emoji))
        if not role_id:
            return
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        role = guild.get_role(role_id)
        if role:
            try:
                await payload.member.add_roles(role, reason="Self-role reaction")
            except discord.Forbidden:
                pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        data = await storage.load("selfroles", {})
        entry = data.get(str(payload.message_id))
        if not entry:
            return
        role_id = entry["roles"].get(str(payload.emoji))
        if not role_id:
            return
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        member = guild.get_member(payload.user_id)
        role = guild.get_role(role_id)
        if member and role:
            try:
                await member.remove_roles(role, reason="Self-role reaction removed")
            except discord.Forbidden:
                pass

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(SelfRoles(bot))
