import datetime

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils import storage

TICKET_CATEGORIES = {
    "general": "General Support",
    "billing": "Billing Issue",
    "report": "Report a User",
}


async def close_ticket_channel(interaction: discord.Interaction):
    """Shared logic for closing a ticket, used by both the button and the
    /close_ticket slash command."""
    channel = interaction.channel
    await interaction.response.send_message("🔒 Closing this ticket in 5 seconds...")

    log_channel = interaction.guild.get_channel(config.TICKET_LOG_CHANNEL_ID)
    if log_channel:
        await log_channel.send(
            f"Ticket `{channel.name}` was closed by {interaction.user.mention}."
        )

    # Remove from the open-tickets index
    tickets = await storage.load("tickets", {})
    for user_id, channel_ids in list(tickets.items()):
        if channel.id in channel_ids:
            channel_ids.remove(channel.id)
            tickets[user_id] = channel_ids
    await storage.save("tickets", tickets)

    await discord.utils.sleep_until(
        discord.utils.utcnow() + datetime.timedelta(seconds=5)
    )
    await channel.delete(reason=f"Ticket closed by {interaction.user}")


class TicketCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, custom_id="ticket_close_button")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await close_ticket_channel(interaction)


class TicketSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label=v, value=k, description=f"Open a {v.lower()} ticket")
            for k, v in TICKET_CATEGORIES.items()
        ]
        super().__init__(
            placeholder="Select a ticket category...",
            options=options,
            custom_id="ticket_category_select",
        )

    async def callback(self, interaction: discord.Interaction):
        guild = interaction.guild
        category_key = self.values[0]
        category_name = TICKET_CATEGORIES[category_key]

        tickets = await storage.load("tickets", {})
        user_tickets = tickets.get(str(interaction.user.id), [])

        # Prevent duplicate open tickets for the same user
        for ch_id in list(user_tickets):
            ch = guild.get_channel(ch_id)
            if ch:
                await interaction.response.send_message(
                    f"You already have an open ticket: {ch.mention}", ephemeral=True
                )
                return
            else:
                user_tickets.remove(ch_id)

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True
            ),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True),
        }
        support_role = guild.get_role(config.TICKET_SUPPORT_ROLE_ID)
        if support_role:
            overwrites[support_role] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True
            )

        category = guild.get_channel(config.TICKET_CATEGORY_ID)
        category = category if isinstance(category, discord.CategoryChannel) else None

        channel = await guild.create_text_channel(
            name=f"ticket-{interaction.user.name}".lower()[:90],
            category=category,
            overwrites=overwrites,
            reason=f"Ticket opened by {interaction.user}",
        )

        user_tickets.append(channel.id)
        tickets[str(interaction.user.id)] = user_tickets
        await storage.save("tickets", tickets)

        embed = discord.Embed(
            title=f"🎫 {category_name}",
            description=(
                f"Hello {interaction.user.mention}, thanks for reaching out.\n"
                "Please describe your issue in detail and a staff member will "
                "be with you shortly.\n\nUse the button below to close this "
                "ticket once it's resolved."
            ),
            color=discord.Color.green(),
        )
        await channel.send(
            content=f"{interaction.user.mention} {support_role.mention if support_role else ''}",
            embed=embed,
            view=TicketCloseView(),
        )
        await interaction.response.send_message(f"✅ Ticket created: {channel.mention}", ephemeral=True)


class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelect())


class Tickets(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketCloseView())

    @app_commands.command(name="setup_tickets", description="Post the ticket panel in this channel")
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_tickets(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="🎫 Support Tickets",
            description="Select a category below to open a private support ticket.",
            color=discord.Color.blurple(),
        )
        await interaction.channel.send(embed=embed, view=TicketPanelView())
        await interaction.response.send_message("Ticket panel posted.", ephemeral=True)

    @app_commands.command(name="close_ticket", description="Close the current ticket channel")
    async def close_ticket(self, interaction: discord.Interaction):
        tickets = await storage.load("tickets", {})
        is_ticket_channel = any(
            interaction.channel.id in ch_ids for ch_ids in tickets.values()
        )
        if not is_ticket_channel:
            await interaction.response.send_message("This isn't a ticket channel.", ephemeral=True)
            return
        await close_ticket_channel(interaction)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Tickets(bot))
