"""
Very small JSON-file storage layer used for persistence (tickets,
self-roles, giveaways) so data survives bot restarts without needing a
database.
"""

import json
import os
import asyncio

_lock = asyncio.Lock()
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
os.makedirs(DATA_DIR, exist_ok=True)


def _path(name: str) -> str:
    return os.path.join(DATA_DIR, f"{name}.json")


async def load(name: str, default=None):
    async with _lock:
        path = _path(name)
        if not os.path.exists(path):
            return default if default is not None else {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default if default is not None else {}


async def save(name: str, data) -> None:
    async with _lock:
        path = _path(name)
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, path)
