#!/usr/bin/env bash
# Convenience startup script for Linux/macOS.
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi

source .venv/bin/activate
pip install -r requirements.txt --quiet

if [ ! -f ".env" ]; then
    echo "No .env file found. Copy .env.example to .env and fill in your values first."
    exit 1
fi

python bot.py
