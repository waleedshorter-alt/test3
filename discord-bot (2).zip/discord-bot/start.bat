@echo off
cd /d "%~dp0"

if not exist ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate.bat
pip install -r requirements.txt --quiet

if not exist ".env" (
    echo No .env file found. Copy .env.example to .env and fill in your values first.
    pause
    exit /b 1
)

python bot.py
pause
