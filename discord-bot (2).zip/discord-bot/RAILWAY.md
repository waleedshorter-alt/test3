# Deploying to Railway

Railway runs this bot as a **worker** (no public URL needed — the bot only
makes outbound connections to Discord's gateway).

## Option A — Deploy from GitHub (recommended)

1. Push this project to a GitHub repo (private is fine).
   ```bash
   cd discord-bot
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
   Your `.gitignore` already excludes `.env` and `data/*.json`, so your
   token and local data won't get committed.

2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo** → pick your repo.

3. Railway auto-detects Python (via `requirements.txt`) using Nixpacks and
   will use the included **`Procfile`** (`worker: python bot.py`) as the
   start command — no build config needed.

4. Open the service → **Variables** tab → add every variable from your
   `.env.example`, filled in with your real values (at minimum `DISCORD_TOKEN`).
   Do this by pasting the whole `.env` file at once with the **"Raw Editor"**
   in that tab, or add them one at a time.

5. Under **Settings**, Railway should show the service type as a **Worker**
   (no domain/networking needed). If it tries to assign a public domain,
   you can ignore or remove it — this bot doesn't listen on any port.

6. Deploy. Check the **Deployments → Logs** tab — you should see
   `Logged in as YourBot#0000`.

## Option B — Deploy with the Railway CLI

```bash
npm install -g @railway/cli   # or: brew install railway
railway login
cd discord-bot
railway init
railway up
```

Then set your variables either in the dashboard or via CLI:

```bash
railway variables --set "DISCORD_TOKEN=your-token-here"
railway variables --set "GUILD_ID=your-server-id"
# ...repeat for each variable in .env.example
```

## Persisting data (tickets / self-roles / giveaways / invites)

The bot stores its JSON data in `./data/`. Railway's default filesystem is
**ephemeral** — it resets on every redeploy. To keep this data across
deploys:

1. In your Railway service → **Settings → Volumes** → **New Volume**.
2. Set the **mount path** to `/app/data` (or wherever your service's
   working directory is — check the deployment logs if unsure).
3. Redeploy. The bot will now read/write `data/*.json` on the persistent volume.

If you don't attach a volume, the bot still works fine — it just starts
tickets/invites/giveaways/self-roles counts from zero after every redeploy.

## Updating slash commands after deploying

If you change or add slash commands later, just push again — `bot.py`
re-syncs commands (`tree.sync()`) every time it starts up. If you set
`GUILD_ID`, that sync is instant; without it, global command updates can
take up to ~1 hour to show up in Discord.

## Common issues

- **Bot doesn't come online** — check the Logs tab for a stack trace; almost
  always a missing/incorrect `DISCORD_TOKEN`, or the "Server Members" /
  "Message Content" privileged intents not being enabled in the
  [Developer Portal](https://discord.com/developers/applications) (Bot tab).
- **Slash commands missing permission errors from Discord** — re-invite the
  bot with the `applications.commands` scope (see main README step 1.5).
- **"Manage Server" errors from the invite tracker** — give the bot's role
  the Manage Server permission in your server's role settings.
- **Sleeping / going offline on the free trial** — Railway's free trial has
  usage limits; check your plan's usage caps if the bot goes offline after
  a while. A paid Hobby plan removes the sleep/usage-cap behavior for
  always-on workers.
